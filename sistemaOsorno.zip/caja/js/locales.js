rutaLocal = "sistema/locales/" + sessionStorage.localcredencial + "/"
console.log(Math.floor(Math.random()))
var fechaJornadaActual = ""
function cargarprueba() {
    cargadorModulo('app', 'locales', 'localSeleccionado');
}

function cargarLocal(datos) {
    sessionStorage.localactual = datos;
    cargadorModulo('app', 'locales', 'localSeleccionado');
}

function abrirlocal() {
    cargadorModulo('app', 'locales', 'menulocal');
}

//sincronizar estado local
//medinte esta sincronizacion se verificará si existe una jornada activa


function modificarMontoLocal(monto) {
    db.ref(rutaLocal).update({
        monto: monto
    })
}

function abrirLocal(rutaJornada) {
    db.ref(rutaLocal).update({
        estado: true,
        jornada: rutaJornada,
        monto: 0
    })

}

function actualizarValorContadores(maquinaActual) {
    db.ref(rutaDatosContadores).orderByChild('maquina').equalTo(parseInt(maquinaActual)).once('value', function (datosPremiosContador) {
        diferenciaOut = 0;
        diferenciaIn = 0;
        inAnterior = 0;
        outAnterior = 0;
        inHoy = 0;
        outHoy = 0;
        balance = 0;
        llaveContador = ""
        datosPremiosContador.forEach(function (datosPremios) {
            llaveContador = datosPremios.key;



            if (datosPremios.val().estado == undefined){
                wea("Aun no se toman Contadores de esta maquina") 
            }else{
                wea("modificandoContadores");
                multiplicadorMaquina = parseInt(datosPremios.val().multiplicadorMaquina)
                prem = parseInt(datosPremios.val().premiosContador);
                rec = parseInt(datosPremios.val().recaudacionesContador);
                entradas = parseInt(datosPremios.val().entrada) * multiplicadorMaquina;
                salidas = parseInt(datosPremios.val().salida) * multiplicadorMaquina;
                maquina = parseInt(datosPremios.val().maquina)
                difIn = prem - salidas;
                difOut = rec - entradas;
                db.ref(rutaDatosContadores + llaveContador).update({
                    diferenciaOut: difOut,
                    diferenciaIn: difIn,
                    maquina: maquina
                })
            }
      
        })
        console.log('se está actualizando los datos')


    })
}
function cerrarLocal() {
    db.ref(rutaLocal).update({
        estado: false
    })
}

function sincronizarJornadas(local) {

    db.ref("sistema/locales/" + local).on('value', function (datosLocales) {
        console.log(local + " ->" + datosLocales.val().estado)
        if (datosLocales.val().estado == true) {
            //existe jornada activa
            sessionStorage.estadoLocal = true;
            rutas.jornadaActual = datosLocales.val().jornada
            console.log("local abierto");
            cargadorModulo('app', 'turnos', 'panelTurnos')
            rutaDatosImportantesCuadratura = "sistema/jornadas/" + sessionStorage.localcredencial + "/" + rutas.jornadaActual + "/datosImportantes/";
        } else {
            sessionStorage.localactual = false;
            sessionStorage.estadoLocal = false;
            console.log("Local cerrado")
            cargadorModulo('app', 'jornada', 'inactiva')
        }
        validacionJornada = false;


    })
}

function validarJornada() {

    $('#tabNavegacion').html(` `)

    if (sessionStorage.estadoLocal == "true") {

        cargadorModulo('app', 'turnos', 'panelTurnos')
    } else {
        rutas.jornadaActual = '';
        cargadorModulo('app', 'jornada', 'inactiva')
    }

}